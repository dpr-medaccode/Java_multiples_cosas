package com.sqlcrud3.app;

public class GestorCine {

    public static void registrarPelicula() {
        // Permite registrar una nueva película
    }

    public static void listarPeliculas() {
        // Muestra todas las películas disponibles
    }

    public static void registrarSala() {
        // Permite registrar una nueva sala
    }

    public static void listarSalas() {
        // Muestra todas las salas disponibles
    }

    public static void registrarReserva() {
        // Permite registrar una nueva reserva
    }

    public static void listarReservas() {
        // Muestra todas las reservas registradas
    }

    public static void buscarReservasPorPelicula() {
        // Permite buscar reservas por título de película
    }

}
