public class CocheIdException extends Exception {

    public CocheIdException (String mensaje) {

        super(mensaje);

    }
    
}
