public class App {
    public static void main(String[] args) throws Exception {
        
        Persona p = new Persona(19);

        p.setedad(12999);

        System.out.println(p);
    }
}
