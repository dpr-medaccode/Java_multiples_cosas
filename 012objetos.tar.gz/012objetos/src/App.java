public class App {
    public static void main(String[] args) throws Exception {
        
        Persona p1 = new Persona("Javi", "10/09/1999");
        Persona p2 = new Persona("Paco", "10/08/1999");
        
        System.out.println(p1.toString());

    }

}

