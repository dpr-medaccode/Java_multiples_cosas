public class Estructuras_de_control3 {
    public static void main(String[] args) throws Exception {
        
        int num = 5;

        for(int i = 0; i < 8; i++){

            System.out.println(num + i);

            num = num + i;
        }

    }
}
