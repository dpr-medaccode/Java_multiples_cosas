public class Estructuras_de_control7 {
    public static void main(String[] args) throws Exception {
        
       4 18 5 20 6 22 7 24 8
       4 5
       18 20

    }
}

}
