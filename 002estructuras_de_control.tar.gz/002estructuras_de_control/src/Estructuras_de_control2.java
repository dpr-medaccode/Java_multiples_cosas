public class Estructuras_de_control2 {
    public static void main(String[] args) throws Exception {
        
        int i = 0;

        while (i<12) {
            
            i = i + 2;

            System.out.println(i);
            
        }
    

    }
}
