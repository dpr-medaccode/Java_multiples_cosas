public class Estructuras_de_control1 {
    public static void main(String[] args) throws Exception {
        
        int i = 0;

        while (i<5) {
        
            System.out.println(i);

            i++;

        }

    }
    
}
