public class Estructuras_de_control4 {
    public static void main(String[] args) throws Exception {
        
       int num = 6;

       System.out.println(num);

        for(int i = 0; i < 3; i++){
    
        System.out.println(num*3);

        num = num * 3;

        System.err.println(num + 2);

        num = num + 2;

        }

    }
}
