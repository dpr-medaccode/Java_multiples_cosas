public class Tarea1 {
    public static void main(String[] args) throws Exception {

        for (int i = 0; i < 129; i++) {
            System.out.println((char) (i));
        }
        // al ejecutarlo al principio no aparece nada, esos serian los elemetos como el
        // espacio y el salto de linea, creo que ocurre porque es uf-8 y no ascii

    }
}
