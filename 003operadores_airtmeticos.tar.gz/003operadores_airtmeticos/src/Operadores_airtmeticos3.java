public class Operadores_airtmeticos3 {
    public static void main(String[] args) throws Exception {
        boolean val1 = 6;
        boolean val2 = 5;

        
        System.out.println();

        ==
        !=
        >
        <
        >=
        <=

    }
}
