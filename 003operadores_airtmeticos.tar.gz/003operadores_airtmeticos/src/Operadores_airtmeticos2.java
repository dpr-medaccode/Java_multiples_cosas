public class Operadores_airtmeticos2 {
    public static void main(String[] args) throws Exception {
        
        int X = 2;

        int Y = 4;

        int Z = 7;

        if (( X < Y )&&( Y < Z)){

        System.out.println("es acendente");

        }

        else{

            System.out.println("no es accendente");
        }




    }
}
