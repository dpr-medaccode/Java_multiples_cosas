public class Operadores_airtmeticos1 {
    public static void main(String[] args) throws Exception {
        int num1 = 6;
        int num2 = 3;

        int suma = num1 +  num2;
        int resta = num1 -  num2;
        int multiplicacion = num1 * num2;
        double div = num1 /  num2;
        int resto = num1 %  num2;

        System.out.println();
        
    }
}

 