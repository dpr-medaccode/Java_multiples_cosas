public class Perro {

    private String nombre;

    private Persona propietario;

    public Perro(String n) {

        this.nombre = n;

    }

    public void asignarPropietario(Persona p) {

        this.propietario = p;

    }

    
}
