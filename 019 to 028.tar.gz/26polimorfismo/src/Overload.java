public class Overload {

    public void demo(int a) {

        System.out.println("Padre | a: " + a);

    }

    public void demo(int a, int b) {

        System.out.println("Padre | a and b: " + a + " " + b);

    }

}
