public class SubclassOverload extends Overload {

    public void demo(double a) {

        System.out.println("Hija  | a: " + a);

    }

}
