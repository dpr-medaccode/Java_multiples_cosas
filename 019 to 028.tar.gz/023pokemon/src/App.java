public class App {
    public static void main(String[] args) throws Exception {

        Bulbasur b1 = new Bulbasur("Manolo");

        Charmander c1 = new Charmander("Jose", 3);

        Squirtel s1 = new Squirtel("Juan");

        System.out.println(s1);

    }
}