public class Squirtel extends Pokemon {

    public Squirtel(String nombre) {

        super(nombre, "Agua");

    }

    @Override
    public String toString() {

        return "Squitel " + super.nombre + " " + super.ps;

    }

}
