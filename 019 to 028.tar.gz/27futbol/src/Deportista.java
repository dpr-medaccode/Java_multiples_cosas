public interface Deportista {

 public void Entrenar();

 public void jugarPartido();

 public boolean tieneSobrepeso();
    
} 
