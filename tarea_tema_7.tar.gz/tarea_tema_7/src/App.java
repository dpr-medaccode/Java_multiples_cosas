public class App {
    public static void main(String[] args) throws Exception {
        
        Persona p1 = new Persona("02387423", "maria", "20/30/10", "845iure");

        System.out.println(p1);

    }
}
