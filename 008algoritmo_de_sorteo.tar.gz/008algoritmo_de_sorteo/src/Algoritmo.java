import java.util.Scanner;

public class Algoritmo {
    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in);

        System.out.println("inserte el 1º numero");
        int num1 = sc.nextInt();

        System.out.println("inserte el 2º numero");
        int num2 = sc.nextInt();

        System.out.println("inserte el 3º numero");
        int num3 = sc.nextInt();

        System.out.println("inserte el 4º numero");
        int num4 = sc.nextInt();

        System.out.println("inserte el 5º numero");
        int num5 = sc.nextInt();

        System.out.println("inserte el 6º numero");
        int num6 = sc.nextInt();

        System.out.println("inserte el 7º numero");
        int num7 = sc.nextInt();

        System.out.println("inserte el 8º numero");
        int num8 = sc.nextInt();

        for (int i = 100; i != 0; i--) {

            ///////////////////////////////////////////////////////////////////////////////////////////////////////

            if (num1 > num2) {

                int numt1 = num1;

                num1 = num2;

                num2 = numt1;

            }

            if (num3 > num4) {

                int numt2 = num3;

                num3 = num4;

                num4 = numt2;

            }

            if (num5 > num6) {

                int numt3 = num5;

                num5 = num6;

                num6 = numt3;

            }

            if (num7 > num8) {

                int numt4 = num7;

                num7 = num8;

                num8 = numt4;

            }

            ///////////////////////////////////////////////////////////////////////////////////////////////////////

            if (num2 > num3) {

                int numtt1 = num2;

                num2 = num3;

                num3 = numtt1;

            }

            if (num4 > num5) {

                int numtt2 = num4;

                num4 = num5;

                num5 = numtt2;

            }

            if (num6 > num7) {

                int numtt3 = num6;

                num6 = num7;

                num7 = numtt3;

            }

        }

        System.out.println(num1 + " / " + num2 + " / " + num3 + " / " + num4 + " / " + num5 + " / " + num6 + " / "
                + num7 + " / " + num8);
    }

}
