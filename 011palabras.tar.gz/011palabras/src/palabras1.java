public class palabras1 {
    public static void main(String[] args) throws Exception {

        String frase1 = "Castillo amarillo";

        String frase2 = frase1.replace("a", "-");

        System.out.println(frase2);

    }
}
