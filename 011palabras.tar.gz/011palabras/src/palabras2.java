public class palabras2 {
    public static void main(String[] args) throws Exception {

            

    }
}
