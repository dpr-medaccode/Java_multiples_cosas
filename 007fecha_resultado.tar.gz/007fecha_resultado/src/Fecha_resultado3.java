import java.util.Scanner;

public class Fecha_resultado3 {
    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in);

        int X = 5;
        int Y = 60;
        int Z = 10;

        if ((X < Y) && (Y < Z)) {

            System.out.println("es accendente");

        }else {

            System.out.println("no es accendente");

        }

    }

}
