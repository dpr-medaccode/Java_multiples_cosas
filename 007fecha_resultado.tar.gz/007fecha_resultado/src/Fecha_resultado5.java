import java.util.Scanner;

public class Fecha_resultado5 {
    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in);

        int n = 7;

        

        
        



    }   






}
