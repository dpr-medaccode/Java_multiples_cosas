public class Contador {

    private int numero;


    
    
}
