public class App {
    public static void main(String[] args) throws Exception {
        
        Persona p1 = new Persona(25, "Javi");

        System.out.println(p1);

    }
}
