public class Test {

    private String palabra;

    private int numero;

    public String getPalabra() {
        return palabra;
    }

    public void setPalabra(String palabra) {
        this.palabra = palabra;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String toString() {
        return "Test [palabra=" + this.palabra + ", numero=" + this.numero + "]";
    }

    
    
}
