public class App2 {
    public static void main(String[] args) throws Exception {
        
        Persona p1 = new Persona("javi", "ramiz", "21/10/2000", 34);

        p1.setNombre("manolo");

        System.out.println(p1);

        

    }
}
