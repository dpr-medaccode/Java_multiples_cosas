public class Persona {

    private int telefono;

    private String email;

    private String fechanac;

    
    
}
