public class Tarea_1_2 {
    public static void main(String[] args) throws Exception {

        for (int i = 0; i < 9; i++) {

            for (int j = 0; j < 9; j++) {

                if (i > j) {

                    System.out.print(" ");

                }

                else {

                    System.out.print("*");

                }

            }

            System.out.println();

        }

    }
}
