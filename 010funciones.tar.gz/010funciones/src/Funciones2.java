public class Funciones2 {
    public static void main(String[] args) throws Exception {

    }

    public static int[] Ordenar5 (int[] num){

        

        

        return

    }

}
