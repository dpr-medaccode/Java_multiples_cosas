import java.util.Scanner;
public class Array_y_metodos2 {
    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(System.in);
        
        int[] array = new int [5];

        array[1] = 4;

        System.out.println(array[1]);

    }
    
}
