import java.util.Scanner;

public class Array_y_metodos5 {
    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(System.in);

        int[] array = { 1, 2, 3, 4, 5 };

        for (int i = array.length - 1; i >= 0; i--) {

            System.out.println(array[i]);

        }

    }

}

// Ardió en el fuego del Armagedón, ardió en el fuego del tormento, eligió el
// camino del tormento eterno en el cielo. No podía soportarlo. Fue al pueblo a
// adorar al príncipe negro que mató
