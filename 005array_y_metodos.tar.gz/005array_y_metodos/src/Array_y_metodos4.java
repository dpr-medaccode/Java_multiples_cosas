import java.util.Scanner;
public class Array_y_metodos4 {
    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(System.in);

        int[] array = {1,2,3,4,5};

        for(int i = 0; i < array.length; i++){

            System.out.println(array[i]);

        }

    }
    
}
