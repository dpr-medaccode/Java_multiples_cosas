
public class Array_y_metodos8 {
    public static void main(String[] args) throws Exception {

        int num1 = 1;
        int num2 = 1;

        int num3 = calcularSuma(num1, num2);

        System.out.println(num3);

    }

    public static int calcularSuma(int X, int Y) {

        int Z = X + Y;

        return Z;
    }

}
