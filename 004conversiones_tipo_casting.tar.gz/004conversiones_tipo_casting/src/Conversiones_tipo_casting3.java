public class Conversiones_tipo_casting3 {
    public static void main(String[] args) throws Exception {

        int edad = 65;

        if (edad < 18) {

            System.out.println("eres menor de edad");

        }

        else if (edad >= 18 && edad < 65) {

            System.out.println("eres adulto");

        }

        else {

            System.out.println("eres mayor de edad");

        }

    }

}
