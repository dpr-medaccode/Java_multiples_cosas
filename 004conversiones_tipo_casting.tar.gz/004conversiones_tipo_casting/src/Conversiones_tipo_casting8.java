public class Conversiones_tipo_casting8 {
  public static void main(String[] args) throws Exception {

    for (int i = 0; i < 101; i++) {

      System.out.println(i);

    }

  }
  
}
