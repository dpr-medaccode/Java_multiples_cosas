public class Conversiones_tipo_casting2 {
    public static void main(String[] args) throws Exception {
        
       char letra = 'A';
       int letraN = letra;

       System.out.println((char)(letraN+32));
      
       

    }
}
