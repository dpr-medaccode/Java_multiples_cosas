public class Conversiones_tipo_casting1 {
    public static void main(String[] args) throws Exception {
        
       double num1 = 100.55;
       
       int num2 = (int)num1;

       System.out.println(num1);

       System.out.println(num2);

    }

}
