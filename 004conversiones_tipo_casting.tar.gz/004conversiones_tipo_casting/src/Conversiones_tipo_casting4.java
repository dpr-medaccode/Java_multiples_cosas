public class Conversiones_tipo_casting4 {
    public static void main(String[] args) throws Exception {

        int dia = 7;

        switch (dia) {

            case 1:
            case 2:
            case 3:
            case 4:
            case 5:

                System.out.println("laborar");

                break;

            case 6:
            case 7:

                System.out.println("es festivo");

                break;

            default:

                System.out.println("no");
        }

    }

}
